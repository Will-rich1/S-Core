<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subcategory extends Model
{
    use HasFactory;

    protected $fillable = ['category_id', 'name', 'points', 'description', 'is_mandatory', 'is_active', 'created_by'];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    // --- TAMBAHKAN INI AGAR BISA HAPUS ---
    public function submissions()
    {
        // Pastikan 'student_subcategory_id' sesuai dengan nama kolom di database Anda
        return $this->hasMany(Submission::class, 'student_subcategory_id');
    }
}